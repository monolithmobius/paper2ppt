# Guidance

* `timelog.md` The time log for my project.
* `Plan/` Plans for this project.
* `data/` data I acquire during the project
* `src/` source code for my project
* `status_report/` the status report submitted in December
* `meetings/` Records of the meetings I have during the project.
* `dissertation/` source and for my project dissertation
* `presentation/` my presentation: noted that my presentation PPT is generated from this project by PPT_Generator.py. I didn't do post-editing for showing the performance of my program with my own dissertation paper file in LaTeX.
